// src/models/index.ts
import Agent from './agent.model.js';
import Client from './client.model.js';
import DeviceAlert from './device-alert.model.js';
import DeviceEarning from './device-earning.model.js';
import DeviceMetric from './device-metric.model.js';
import DeviceSpecification from './device-specification.model.js';
import MiningDevice from './mining-device.model.js';
import MiningSession from './mining-session.model.js';
import DeviceEarningPot from './device-earning-pot.model.js';
import Permission from './permission.model.js';
import RolePermission from './role-permission.model.js';
import Role from './role.model.js';
import Setting from './setting.model.js';
import Transaction from './transaction.model.js';
import UserPermission from './user-permission.model.js';
import UserSession from './user-session.model.js';
import UserWallet from './user-wallet.model.js';
import User from './user.model.js';
import WithdrawalRequest from './withdrawal-request.model.js';
import DevicePotAssignment from './device-pot-assignment.js';
import DeviceAffiliate from './device-affiliate.model.js';
import { models } from '../db.js';

const initModels = (sequelize: any) => {


  const models = {

    // base tables
    User: User.initModel(sequelize),
    Role: Role.initModel(sequelize),
    Permission: Permission.initModel(sequelize),
    Agent: Agent.initModel(sequelize),
    Client: Client.initModel(sequelize),
    // user relations
    UserSession: UserSession.initModel(sequelize),
    UserWallet: UserWallet.initModel(sequelize),

    // device money
    DeviceEarningPot: DeviceEarningPot.initModel(sequelize),

    // devices
    MiningDevice: MiningDevice.initModel(sequelize),
    DevicePotAssignment: DevicePotAssignment.initModel(sequelize),
    DeviceAffiliate: DeviceAffiliate.initModel(sequelize),

    DeviceSpecification: DeviceSpecification.initModel(sequelize),
    DeviceMetric: DeviceMetric.initModel(sequelize),
    DeviceAlert: DeviceAlert.initModel(sequelize),
    MiningSession: MiningSession.initModel(sequelize),
    DeviceEarning: DeviceEarning.initModel(sequelize),

    // money operations
    WithdrawalRequest: WithdrawalRequest.initModel(sequelize),
    Transaction: Transaction.initModel(sequelize),

    // other

    Setting: Setting.initModel(sequelize),

    RolePermission: RolePermission.initModel(sequelize),
    UserPermission: UserPermission.initModel(sequelize),
  };




  Object.values(models).forEach((model: any) => {
    if (model.associate) {
      model.associate(models);
    }
  });


  return models;
};

export default initModels;


