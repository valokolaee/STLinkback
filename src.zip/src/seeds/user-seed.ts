// src/seeds/user-seed.ts
// import { User } from '../db/models/User';
import bcrypt from 'bcryptjs';
import User from '../db/models/user.model';

export const seedUsers = async () => {
  const hashedPassword = bcrypt.hashSync('admin123', 8);

  await User.create({
    username: 'admin',
    email: 'admin@example.com',
    password_hash: hashedPassword,
    role_id: 1,
    client_type: 'individual',
  });
};