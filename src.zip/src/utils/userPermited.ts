// src/middleware/auth.middleware.ts
import { Request, Response } from 'express';
import Role, { IRole } from '../db/models/role.model';
import { IUser } from '../db/models/user.model';
import { agentRoles, clientRoles } from './initialRolesList';
import responserUtils from './responser.utils';

export default async (req: Request, res: Response, user: IUser) => {

  try {
    const r = await Role.findByPk(user.roleId);

    const roleName = r?.name;
    const baseUrl = req.baseUrl.toString().split('/');

    const api = baseUrl.length > 0 ? baseUrl[1] : '';

    var _rolls: IRole[] = [];

    if (api === 'api') {
      _rolls = clientRoles
    } else if (api === 'panel') {
      _rolls = agentRoles;
    } else {

      return responserUtils(res, 401, {
        success: false,
        message: 'Invalid access route'
      });
    }



    const _permitted = _rolls.some(obj => obj.name === roleName);
    if (!_permitted) {
      return responserUtils(res, 403, {
        success: false,
        message: 'You do not have permission to access this resource'
      });
    }

  } catch (error: any) {

  }
};