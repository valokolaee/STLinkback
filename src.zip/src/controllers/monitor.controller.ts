import { Request, Response } from 'express';
import { models } from '../db/db';
import { IDeviceAlert } from '../db/models/device-alert.model';
import DeviceEarningPot from '../db/models/device-earning-pot.model';
import { IDeviceEarning } from '../db/models/device-earning.model';
import { IDeviceMetric } from '../db/models/device-metric.model';
import MiningDevice, { IMiningDevice } from '../db/models/mining-device.model';
import { IMiningSession } from '../db/models/mining-session.model';
import IServiceResult from '../interfaces/IServiceResult';
import DeviceEarningService from '../services/DeviceEarning.service';
 import RolePermissionService from '../services/RolePermission.service';
import responserUtils from '../utils/responser.utils';
import DeviceAlertService from '../services/DeviceAlert.service';




const serviceRolePermission = RolePermissionService(models.RolePermission)

const serviceDeviceEarning = DeviceEarningService(models.DeviceEarning)

export default {

  async getAll(req: Request, res: Response) {
    try {

      const items = await serviceRolePermission.getAll();


      if (items.ok) {
        return responserUtils(res, 200, { success: true, data: items.data })
      } else {
        return responserUtils(res, 404, { success: false, })
      }


    } catch (error) {

      return responserUtils(res, 500, { success: false, }, error)

    }
  },



  async getAllBy(req: Request, res: Response) {
    try {

      const device: IMiningDevice = req?.body;
      const { id: deviceId, } = device || {}

      const _deviceInfo: IMiningDevice = await MiningDevice.findByPk(deviceId, {
        include: [
          {
            model: DeviceEarningPot,
            as: 'currentPot',
          }
        ],
        raw: true,  // Returns plain object, no Sequelize methods
        nest: true  // Nests the client object properly
      }) as IMiningDevice






      const _alerts: IServiceResult<IDeviceAlert[]> = await DeviceAlertService(models.DeviceAlert).getAllBy({ deviceId }, [['createdAt', 'desc']]);
      var _alert = null;
      if (_alerts?.data!?.length > 0) {
        _alert = _alerts.data!;

      }

      const _metrics: IServiceResult<IDeviceMetric[]> = await DeviceAlertService(models.DeviceMetric).getAllBy({ deviceId }, [['recordedAt', 'desc']], 10);

      var _metric = null;
      if (_metrics?.data!?.length > 0) {
        _metric = _metrics?.data!;
      }

      const _sessions: IServiceResult<IMiningSession[]> = await DeviceAlertService(models.MiningSession).getAllBy({ deviceId }, [['createdAt', 'desc']]);

      var _currentSession: IMiningSession = {}
      if (_metrics?.data!?.length > 0) {
        _currentSession = _sessions?.data![0];
      }



      const items: IServiceResult<IDeviceEarning[]> = await serviceDeviceEarning.getAllBy({ deviceId }, [['calculatedAt', 'desc']], 10);


      const monitorData = {
        alerts: _alert,
        metrics: _metric,
        wallet: _deviceInfo!?.currentPot,
        session: _currentSession,
        lastEarnings: items.data
      }



      if (!!_deviceInfo) {
        return responserUtils(res, 200, { success: true, data: monitorData })
      } else {
        return responserUtils(res, 404, { success: false, })
      }

    } catch (error) {

      return responserUtils(res, 500, { success: false, }, error)

    }
  },



}